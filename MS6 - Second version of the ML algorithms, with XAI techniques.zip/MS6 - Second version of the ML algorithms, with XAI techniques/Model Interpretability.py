import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
import shap
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.callbacks import EarlyStopping, ModelCheckpoint

#--- Lettura input ---#
orbit_to_remove = []
with open('data/orbit_to_remove') as file:
    for line in file:
        orbit_to_remove.append(float(line))

df = pd.read_csv("data/all_past.csv", sep=";")

#--- Elaborazione input ---#
frequency_to_keep = 4000000.0
df = df[df['FM_data_frequency'] == frequency_to_keep]
#df = df.replace([np.inf, -np.inf], np.nan).dropna() #ci sono nan solo nella colonna simulated
df = df[~df.FM_data_orbit_number.isin(orbit_to_remove)] #rimuovo l'8% dei dati
df['FM_data_solar_longitude_cos'] = np.cos(df['FM_data_solar_longitude']) #coverto l'angolo in sin e cos
df['FM_data_solar_longitude_sin'] = np.sin(df['FM_data_solar_longitude'])
#df = df.sample(frac=1, random_state=0)

X = df.drop(columns=['FM_data_ephemeris_time', 'FM_data_F10_7_index', 'FM_data_frequency', 'FM_data_median_corrected_echo_power', 'FM_data_orbit_number', 'FM_data_peak_corrected_echo_power', 'FM_data_peak_distorted_echo_power', 'FM_data_peak_simulated_echo_power', 'FM_data_solar_longitude'])
col_names = X.columns.tolist()
X = X.to_numpy()

y = df['FM_data_peak_distorted_echo_power'].to_numpy()

#--- Algoritmi da testare ---#

algorithm = {
    'knn': KNeighborsRegressor(),
    'linear_regression': LinearRegression(),
    'decision_tree': DecisionTreeRegressor(random_state=0, criterion='squared_error', max_depth=20),
    'gr_boosting': GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=20, random_state=0, criterion='squared_error'),
    'random_forest': RandomForestRegressor(n_estimators=100, criterion='squared_error', random_state=0, max_depth=20, n_jobs=16),#16
    'random_forest2': RandomForestRegressor(criterion='squared_error', random_state=0, max_depth=25, n_jobs=16),
    'neural_network': MLPRegressor(hidden_layer_sizes=(30, 15,), max_iter=50000, random_state=1, early_stopping=True),
    'support_v_r': SVR(max_iter=20000),
    'neural_network_keras': Sequential([
        Dense(200, input_dim=X.shape[1], activation='relu'),
        Dropout(0.5),
        Dense(100, activation='relu'),
        Dropout(0.5),
        Dense(50, activation='relu'),
        Dropout(0.5),
        Dense(1, activation='relu')])
}

def prediction(alg, small):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, train_size=0.8, shuffle=False)

    # standardizzo le features
    if small in ["knn", "lr", "nn", "svr", "nnk"]:
        scaler = StandardScaler() #solo per lr e knn
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)

    es = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=10)

    model = algorithm[alg]
    #model.fit(X_train, y_train)

    model.compile(loss='mse', optimizer='adam', metrics=['mean_absolute_error'])  #
    model.fit(X_train, y_train, validation_split=0.1, epochs=1000, callbacks=[es])  #
    print("uno")
    explainer = shap.Explainer(model.predict, X_test)
    print("due")
    shap_values = explainer(X_test)
    shap.summary_plot(shap_values.values, X_test, col_names, plot_type='violin')
    #shap.dependence_plot(col_names.index('FM_data_slope'), shap_values, X_test, col_names, interaction_index=col_names.index('FM_data_altitude'))
    #shap.waterfall_plot(shap_values[0])


#prediction("random_pred","rand")
#prediction("knn", "knn")
#prediction("linear_regression", "lr")
#prediction("decision_tree", "dt")
#prediction("random_forest", "rf")
#prediction("gr_boosting", "gb")
#prediction("neural_network", "nn")
#prediction("support_v_r", "svr")
prediction("neural_network_keras", "nnk")

