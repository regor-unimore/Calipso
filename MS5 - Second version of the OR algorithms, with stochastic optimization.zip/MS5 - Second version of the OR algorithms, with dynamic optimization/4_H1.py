import time
import numpy as np
import random

# Define INSTANCE
#parser = argparse.ArgumentParser(description="Code to solve the ILP model")
#parser.add_argument('instance_name', type=str, help="Name of the instance")
#args = parser.parse_args()
#name = args.instance_name

name = 'M_10_134_4'

name_char = name.split('_')

# Parameters
G = name_char[1]    # granularity
L = name_char[2]    # length
NC = name_char[3]   # number of quality classes
gra = {'01': 1000, '02': 2000, '03': 3000, '05': 5000, '10': 10000}
nO = 113651         # number of observations

instances = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis/Ottimizzazione/Mars2023-2025/Final_Instances'
scenarios = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis_2/Scenari'

# Default settings
N = 1                   # number of observation per day
V = [0, 0.25, 0.5, 1]   # class quality weights
W = [1, 1]              # [1/beta, 1], score for AOI

#  Information on PIs
cPIAV = []
wPI = []
with open(f"{instances}/{name}/{name}(1).txt", 'r') as file:
    lines = file.readlines()
    nPI = len(lines)        # number of PI
    for line in lines:
        line = list(line.strip().split(' '))
        cPIAV.append(V[int(line[5])])
        wPI.append(W[int(line[6])])

#  PI in observations
with open(f"{instances}/{name}/{name}(2).txt", "r") as file:
    PIinO = [[int(i) for i in line.strip().split("\t")]
            if line != "" and line != "\n" else [] for line in file.readlines()]

# Day of the observations
with open(f"{instances}/day.txt", "r") as file:
    day = [line for line in file.readlines()]

ranges = {}
beg = 0
while beg < nO: #scorro tutti i giorni
    end = beg
    while end+1 < nO and day[end+1] == day[beg]:
        end = end+1
    ranges[day[beg]] = range(beg, end+1)
    beg = end+1

N_scenario = 1
'''
SET_SIZE = 5  # numero set
UNIVERSE = list(range(1, 101))  # numeri da 1 a 50
random.seed(42)  # opzionale, per avere risultati riproducibili
'''
#----------------------------------------------------------------------------------------
'''
for N_scenario in [1, 5, 10, 20, 50]: 

    # genero i 5 gruppi di scenari
    sets = []
    seen = set()  # per evitare insiemi totalmente coincidenti
    while len(sets) < SET_SIZE:
        s = frozenset(random.sample(UNIVERSE, N_scenario))
        if s not in seen:
            seen.add(s)
            sets.append(list(s))
    print(sets)

    if N_scenario in [20, 50]:
        for i in range(SET_SIZE):

            S = sets[i]
            print(S)
'''

for ii in range(511, 521):
    S = [ii]
    # Class of the quality of PIs in observations for each scenario s, weighted through set V
    cPIinO = {}
    for s in S:
        with open(f"{scenarios}/{name}/{name}(4)_{s}_truescenario.txt", "r") as file:
            cPIinO[s] = [[V[int(i)] for i in line.strip().split("\t")]
                            if line != "" and line != "\n" else [] for line in file.readlines()]

    ############################# MAIN #####################################

    selected = [0]*nO
    visited = [0]*nPI
    w_quality = {s: cPIAV[:] for s in S}

    # solution construction
    t1 = time.time()

    beg = 0
    while beg < nO:  # scorro tutti i giorni
        end = beg
        while end+1 < nO and day[end+1] == day[beg]:
            end = end+1
        cur = PIinO[beg:(end+1)]
        curI = range(beg, end+1)  # indice della riga che contiene lo scatto

        for k in range(N):  # i[0] = riga di PIpp, j = indice di posto, i[0][j] = nome del PI
            curS = sorted(zip(cur, curI), key=lambda i: sum(max(0, (cPIinO[s][i[1]][j] - w_quality[s][i[0][j]])) for s in S for j in range(len(i[0])))) #* w_scorePI[i[0][j]]
            if len(curS) >= 1:
                maxobs = curS[-1]
                selected[maxobs[1]] = 1  # prendo l'ultimo, qualità totale maggiore
                for s in S:
                    for l, j in enumerate(maxobs[0]):  # per ogni PI nello scatto selezionato
                        w_quality[s][j] = max(w_quality[s][j], cPIinO[s][maxobs[1]][l])
                        visited[j] = 1
        beg = end+1

    # compute objective function
    ob = 0
    for s in S:
        for j in range(nPI):
            if w_quality[s][j] > cPIAV[j]:
                ob += (w_quality[s][j] - cPIAV[j]) #* w_scorePI[j]

    t2 = time.time()
    print("objective function = ", ob)
    print("visited PI = ", sum(visited))
    print("execution time = ", t2 - t1)
    # print solution

    f = open(f"Soluzioni/H1/H1_{name}_{N_scenario}_{ii}_truescenario.txt","w+") # H1_{name}_{N_scenario}_{i}
    f.write(f"objective function = {ob}\nvisited PI = {sum(visited)}\nexecution time = {t2 - t1}\n")
    for j in S:
        f.write(f"{j}\t")
    f.write('\n')
    for i in selected:
        f.write("%d\n" % i)
    f.close()

