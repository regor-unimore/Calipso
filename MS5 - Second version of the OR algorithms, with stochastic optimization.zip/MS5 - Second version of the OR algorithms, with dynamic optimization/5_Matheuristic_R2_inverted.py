import random
from statistics import mean

import numpy as np
import time
import gurobipy as gp
from gurobipy import GRB

# Define INSTANCE
#parser = argparse.ArgumentParser(description="Code to solve the ILP model")
#parser.add_argument('instance_name', type=str, help="Name of the instance")
#args = parser.parse_args()
#name = args.instance_name

name = 'M_01_134_4'

name_char = name.split('_')

# Parameters
G = name_char[1]    # granularity
L = name_char[2]    # length
NC = name_char[3]   # number of quality classes
gra = {'01': 1000, '02': 2000, '03': 3000, '05': 5000, '10': 10000}
nO = 113651         # number of observations

instances = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis/Ottimizzazione/Mars2023-2025/Final_Instances'
scenarios = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis_2/Scenari'

# Default settings
N = 1                   # number of observation per day
V = [0, 0.25, 0.5, 1]   # class quality weights
W = [1, 1]              # [1/beta, 1], score for AOI

#test parameters
seeds = [9, 71, 672, 193, 6846, 9099, 19073, 14093, 70380, 91004]
ttype = {'01':'VLR', '02':'LR', '03':'MR', '05':'HR', '10':'VHR'}
limits = {'VHR': [160, 80, 40, 20], 'HR': [80, 40, 20, 10], 'MR': [40, 20, 10, 5], 'LR': [20, 10, 5, 2], 'VLR': [10, 5, 2, 1]}

#  Information on PIs
cPIAV = []
wPI = []
with open(f"{instances}/{name}/{name}(1).txt", 'r') as file:
    lines = file.readlines()
    nPI = len(lines)        # number of PI
    for line in lines:
        line = list(line.strip().split(' '))
        cPIAV.append(V[int(line[5])])
        wPI.append(W[int(line[6])])

#  PI in observations
with open(f"{instances}/{name}/{name}(2).txt", "r") as file:
    PIinO = [[int(i) for i in line.strip().split("\t")]
            if line != "" and line != "\n" else [] for line in file.readlines()]

# Day of the observations
with open(f"{instances}/day.txt", "r") as file:
    day = [line for line in file.readlines()]

SET_SIZE = 5  # numero set
UNIVERSE = list(range(1, 101))  # numeri da 1 a 50
random.seed(42)  # opzionale, per avere risultati riproducibili

# ----------------------------------------------------------------------------------------

for N_scenario in [1, 5, 10, 20, 50]:

    # genero i 5 gruppi di scenari
    sets = []
    seen = set()  # per evitare insiemi totalmente coincidenti
    while len(sets) < SET_SIZE:
        s = frozenset(random.sample(UNIVERSE, N_scenario))
        if s not in seen:
            seen.add(s)
            sets.append(list(s))

    if N_scenario in [50]:
        for ii in range(1, SET_SIZE):

            S = sets[ii]
            print(S)

            # Class of the quality of PIs in observations for each scenario s, weighted through set V
            cPIinO = {}
            for s in S:
                with open(f"{scenarios}/{name}/{name}(4)_{s}.txt", "r") as file:
                    cPIinO[s] = [[V[int(i)] for i in line.strip().split("\t")]
                                    if line != "" and line != "\n" else [] for line in file.readlines()]

            with open(f"Soluzioni/H1/H1_{name}_{N_scenario}_{ii}.txt", "r") as file:
                obj = float(file.readline().split("=")[1])
                file.readline()
                file.readline()
                file.readline()
                selected_h2 = [int(file.readline()) for i in range(nO)]

            ######################### MODEL EXECUTION ###############################

            n_iter = 1
            step = 0.10
            coeff_0 = 0.85

            obj_values = []
            coverture_values = []
            time_values = []
            iter_values = []

            for k in range(n_iter):

                # time
                t0 = time.time()
                tf = 0
                tmodel = 0

                iter_w_imp = 0
                index = 0
                ilim = 0
                coeff = coeff_0

                test = []
                selected = selected_h2
                np.random.seed(seeds[k])

                while tf < 3600:

                    # update coeff
                    index += 1
                    if iter_w_imp == limits[ttype[G]][ilim]:
                        if ilim == 3:
                            break
                        ilim += 1
                        coeff -= step
                        iter_w_imp = 0
                    print(f'Iteration: {index}, Coeff: {coeff}')

                    # Selection of random observations to fix
                    day_fix = {day[i]: 0 for i in range(nO)}
                    day_fix_r = np.random.random(len(day_fix))
                    idx = 0
                    for d in day_fix.keys():
                        if day_fix_r[idx] < coeff:
                            day_fix[d] = 1
                        idx+=1
                    print(sum(day_fix.values()))

                    # Fix the selected variables
                    unfixed = [o for o in range(nO) if day_fix[day[o]] == 0]

                    # Update cPIAV for points covered by fixed observations
                    cPIAV2 = {s: cPIAV[:] for s in S}
                    for o in range(nO):
                        if o not in unfixed and selected[o] == 1:
                            for p in range(len(PIinO[o])):
                                for s in S:
                                    cPIAV2[s][PIinO[o][p]] = max(cPIAV2[s][PIinO[o][p]], cPIinO[s][o][p])

                    ######################### MODEL ####################################################
                    model = gp.Model()
                    model.setParam("TimeLimit", 360)
                    model.setParam(GRB.Param.Threads, 1)
                    model.setParam(GRB.Param.Method, 2)
                    model.setParam("MIPGap", 1e-6)

                    z = 0
                    VPI = list(set([i for o in range(nO) for i in PIinO[o]]))
                    PC = {(PIinO[o][i], cPIinO[s][o][i], s): 1 for o in unfixed for i in range(len(PIinO[o])) for s in
                          S}  # feasible (p, c) couples, c = class of quality q
                    NumPC = {(p, c, s): 0 for (p, c, s) in PC.keys()}  # number of time PI is covered with class c
                    NumObsPerDay = {day[o]: 0 for o in unfixed}  # number of observations selected for each day

                    # Variables
                    xo = model.addVars(unfixed, lb=0, ub=1, vtype=GRB.INTEGER, name='X')
                    y = model.addVars(PC.keys(), lb=0, ub=1, vtype=GRB.INTEGER, name='y')
                    for o in unfixed:
                        xo[o].setAttr("start", selected[o])

                    model.update()

                    for o in unfixed:
                        NumObsPerDay[day[o]] += xo[o]
                        for i in range(len(PIinO[o])):
                            for s in S:
                                NumPC[(PIinO[o][i], cPIinO[s][o][i], s)] += xo[o]

                    # Objective function
                    for (p, c, s) in PC.keys():
                        if c > cPIAV2[s][p]:
                            z += y[(p, c, s)] * (c - cPIAV2[s][p]) * wPI[p]

                    model.setObjective(z, sense=gp.GRB.MAXIMIZE)

                    # Constraints
                    model.addConstrs(y[(p, c, s)] <= NumPC[(p, c, s)] for (p, c, s) in PC.keys())
                    model.addConstrs(y.sum(p, '*', s) <= 1 for p in VPI for s in S)
                    model.addConstrs(NumObsPerDay[d] <= N for d in NumObsPerDay.keys())

                    ###########################################################################################

                    tm1 = time.time() - t0  # inizio modello  START M
                    model.optimize()
                    tm2 = time.time() - t0  # fine modello  END M
                    tmodel += tm2 - tm1

                    # retrieve solution and compute real obj.function considering fixed observations
                    print(f'Is the solution optimal? {model.status == gp.GRB.OPTIMAL}')
                    print(f'Partial Solution: {z.getValue()}\n')

                    obj_prec = obj
                    q = {s: cPIAV[:] for s in S}
                    for o in range(nO):
                        if o in unfixed:
                            selected[o] = xo[o].x
                        if selected[o] == 1:
                            for j in range(len(PIinO[o])):
                                for s in S:
                                    q[s][PIinO[o][j]] = max(q[s][PIinO[o][j]], cPIinO[s][o][j])
                    obj = sum((q[s][j] - cPIAV[j]) * wPI[j] for j in range(nPI) for s in S)
                    print(f'Complete Solution: {obj}\n')
                    # coefficient update
                    if obj_prec == obj:
                        iter_w_imp += 1
                    else:
                        iter_w_imp = 0
                        test.append([index, coeff, obj, tm1, tm2, time.time() - t0])
                    tf = time.time() - t0  # T END

                # end while
                visited = [0] * nPI
                for o in range(nO):
                    if selected[o] == 1:
                        for p in PIinO[o]:
                            visited[p] = 1
                coverture = sum(visited)
                tf = time.time() - t0
                time_values.append(tf)
                iter_values.append(index)
                obj_values.append(obj)
                coverture_values.append(coverture)

                g = open(f"Soluzioni/R2_inverted/{ttype[G]}_{coeff_0}_{step}_R2inverted_{name}_{N_scenario}_{ii}.txt", "a")
                g.write(f'Objective Value = {obj} \n')
                g.write(f'Number of PI covered = {coverture} \n')
                g.write(f'Total execution time = {tf} \n')
                g.write(f'Total model time = {tmodel} \n')
                g.write(f'Number of iterations = {index} \n')
                g.write('Iter Coeff Obj StartM EndM Tend\n')
                for i in test:
                    g.write(f'{i[0]} {i[1]} {i[2]} {i[3]} {i[4]} {i[5]} \n')
                g.write('\n')
                g.close()

                f = open(f"Soluzioni/R2_inverted/{ttype[G]}_{coeff_0}_{step}_R2inverted(sol)_{name}_{N_scenario}_{ii}.txt", "a")
                f.write(f'Objective Value = {obj} \n')
                for i in selected:
                    f.write("%d\n" % i)
                f.close()

            f = open(f"Soluzioni/R2_inverted/{ttype[G]}_{coeff_0}_{step}_R2inverted_{name}_{N_scenario}_{ii}.txt", "a")
            for j in S:
                f.write(f"{j}\t")
            f.write('\n')
            f.write('Max objective function = ' + str(max(obj_values)) + '\n')
            f.write('Max number of PI covered = ' + str(max(coverture_values)) + '\n')
            f.write('Max number of iterations = ' + str(max(iter_values)) + '\n')
            f.write('Max total time = ' + str(max(time_values)) + '\n\n')
            f.write('Average objective function = ' + str(mean(obj_values)) + '\n')
            f.write('Average number of PI covered = ' + str(mean(coverture_values)) + '\n')
            f.write('Average number of iterations = ' + str(mean(iter_values)) + '\n')
            f.write('Average total time = ' + str(mean(time_values)) + '\n\n')