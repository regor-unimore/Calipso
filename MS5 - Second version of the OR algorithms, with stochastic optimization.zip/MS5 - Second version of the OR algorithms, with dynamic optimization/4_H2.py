import time
import numpy as np
import random

# Nb dots
# Define INSTANCE
#parser = argparse.ArgumentParser(description="Code to solve the ILP model")
#parser.add_argument('instance_name', type=str, help="Name of the instance")
#args = parser.parse_args()
#name = args.instance_name

name = 'M_10_134_4'

name_char = name.split('_')

# Parameters
G = name_char[1]    # granularity
L = name_char[2]    # length
NC = name_char[3]   # number of quality classes
gra = {'01': 1000, '02': 2000, '03': 3000, '05': 5000, '10': 10000}
nO = 113651         # number of observations
#N_scenario = 50

instances = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis/Ottimizzazione/Mars2023-2025/Final_Instances'
scenarios = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis_2/Scenari'

# Default settings
N = 1                   # number of observation per day
V = [0, 0.25, 0.5, 1]   # class quality weights
W = [1, 1]              # [1/beta, 1], score for AOI

#  Information on PIs
cPIAV = []
wPI = []
with open(f"{instances}/{name}/{name}(1).txt", 'r') as file:
    lines = file.readlines()
    nPI = len(lines)        # number of PI
    for line in lines:
        line = list(line.strip().split(' '))
        cPIAV.append(V[int(line[5])])
        wPI.append(W[int(line[6])])

#  PI in observations
with open(f"{instances}/{name}/{name}(2).txt", "r") as file:
    PIinO = [[int(i) for i in line.strip().split("\t")]
            if line != "" and line != "\n" else [] for line in file.readlines()]

# Intersections
with open(f"Intersections_{G}_{L}.txt", "r") as file:
    intersections = [[int(x) for x in line.strip().split("\t")] if line.strip() else [] for line in file.readlines()]

# Day of the observations
with open(f"{instances}/day.txt", "r") as file:
    day = [line for line in file.readlines()]

ranges = {}
beg = 0
while beg < nO: #scorro tutti i giorni
    end = beg
    while end+1 < nO and day[end+1] == day[beg]:
        end = end+1
    ranges[day[beg]] = range(beg, end+1)
    beg = end+1

SET_SIZE = 5  # numero set
UNIVERSE = list(range(1, 101))  # numeri da 1 a 50
random.seed(42)  # opzionale, per avere risultati riproducibili

#----------------------------------------------------------------------------------------
for N_scenario in [1, 5, 10, 20, 50]:

    # genero i 5 gruppi di scenari
    sets = []
    seen = set()  # per evitare insiemi totalmente coincidenti
    while len(sets) < SET_SIZE:
        s = frozenset(random.sample(UNIVERSE, N_scenario))
        if s not in seen:
            seen.add(s)
            sets.append(list(s))

    if N_scenario in [1, 5, 10, 20, 50]:
        for ii in range(SET_SIZE):

            S = sets[ii]
            print(S)
            # Class of the quality of PIs in observations for each scenario s, weighted through set V
            cPIinO = {}
            for s in S:
                with open(f"{scenarios}/{name}/{name}(4)_{s}.txt", "r") as file:
                    cPIinO[s] = [[V[int(i)] for i in line.strip().split("\t")]
                                 if line != "" and line != "\n" else [] for line in file.readlines()]

            ############################# MAIN #####################################

            selected = [0] * nO
            visited = [0] * nPI
            w_quality = {s: cPIAV[:] for s in S}
            days = {i: 0 for i in set(day)}

            t1 = time.time()
            z_o = [sum(max(0, cPIinO[s][i][j] - w_quality[s][PIinO[i][j]]) for s in S for j in range(len(PIinO[i]))) for i in range(nO)]  # pesi iniziali

            # solution construction
            while sum(selected) < len(days)*N:

                curS = sorted(range(nO), key=lambda i: z_o[i])
                maxobs = curS[-1]
                if z_o[maxobs] == -1:
                    break
                selected[maxobs] = 1
                for s in S:
                    for l, j in enumerate(PIinO[maxobs]):  # per ogni PI nello scatto selezionato
                        w_quality[s][j] = max(w_quality[s][j], cPIinO[s][maxobs][l])
                        visited[j] = 1
                days[day[maxobs]] += 1
                if days[day[maxobs]] == N or day[maxobs] == '2023NOV17':  # svuoto le osservazioni non selezionabili
                    for i in ranges[day[maxobs]]:
                        z_o[i] = -1

                for i in intersections[maxobs]:#range(nO):  # aggiorni i pesi di chi ha intersezioni
                    if z_o[i] != -1:
                        z_o[i] = sum(max(0, cPIinO[s][i][j] - w_quality[s][PIinO[i][j]]) for s in S for j in range(len(PIinO[i])))

                #ttime = time.time()-t1

            # compute objective function
            ob = 0
            for s in S:
                for j in range(nPI):
                    if w_quality[s][j] > cPIAV[j]:
                        ob += (w_quality[s][j] - cPIAV[j]) #* w_scorePI[j]
            t2 = time.time()

            print("objective function = ", ob)
            print("visited PI = ", sum(visited))
            print("execution time = ", t2-t1)

            #print solution
            f = open(f"Soluzioni/H2/H2matrix_{name}_{N_scenario}_{ii}.txt", "w+")
            f.write(f"objective function = {ob}\nvisited PI = {sum(visited)}\nexecution time = {t2 - t1}\n")
            for j in S:
                f.write(f"{j}\t")
            f.write('\n')
            for i in selected:
                f.write("%d\n" % i)
            f.close()