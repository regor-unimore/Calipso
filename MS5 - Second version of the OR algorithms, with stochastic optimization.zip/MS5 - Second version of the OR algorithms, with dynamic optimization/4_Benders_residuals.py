import time
import gurobipy as gp
import numpy as np
from gurobipy import GRB
import random

# Define INSTANCE
#parser = argparse.ArgumentParser(description="Code to solve the ILP model")
#parser.add_argument('instance_name', type=str, help="Name of the instance")
#args = parser.parse_args()
#name = args.instance_name

name = 'M_01_134_4'

name_char = name.split('_')

# Parameters
G = name_char[1]    # granularity
L = name_char[2]    # length
NC = name_char[3]   # number of quality classes
gra = {'01': 1000, '02': 2000, '03': 3000, '05': 5000, '10': 10000}
nO = 113651         # number of observations

instances = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis/Ottimizzazione/Mars2023-2025/Final_Instances'
scenarios = 'C:/Users/user/Desktop/Ferrari Benedetta/Marsis_2/Scenari'

# Default settings
N = 1                   # number of observation per day
V = [0, 0.25, 0.5, 1]   # class quality weights
W = [1, 1]              # [1/beta, 1], score for AOI

# ----------------------------------- Import ------------------------------------------
#  Information on PIs
cPIAV = []
wPI = []
with open(f"{instances}/{name}/{name}(1).txt", 'r') as file:
    lines = file.readlines()
    nPI = len(lines)        # number of PI
    for line in lines:
        line = list(line.strip().split(' '))
        cPIAV.append(V[int(line[5])])
        #wPI.append(W[int(line[6])])

#  PI in observations
with open(f"{instances}/{name}/{name}(2).txt", "r") as file:
    PIinO = [[int(i) for i in line.strip().split("\t")]
            if line != "" and line != "\n" else [] for line in file.readlines()]

# Day of the observations
with open(f"{instances}/day.txt", "r") as file:
    day = [line for line in file.readlines()]

# ---------------------------------- Functions --------------------------------------
def compute_js(s, K):
    Js = {(PIinO[i][j], cPIinO[s][i][j]): 0 for i in range(nO) for j in range(len(PIinO[i]))}
    for i in K:
        for j in range(len(PIinO[i])):
            Js[(PIinO[i][j], cPIinO[s][i][j])] += 1

    return Js

def real_obj_f(selected, s):
    # calcolo funzione obiettivo reale:
    q = np.array(cPIAV)
    for i in range(nO):
        if selected[i] == 1:
            for j in range(len(PIinO[i])):
                q[PIinO[i][j]] = max(q[PIinO[i][j]], cPIinO[s][i][j])

    real_obj = sum((q[j] - cPIAV[j]) for j in range(nPI))
    return real_obj, q

def residuals_f(selected, s):
    # calcolo funzione obiettivo reale:

    q = np.array(cPIAV)
    count_cov = [0]*nPI
    for i in range(nO):
        if selected[i] == 1:
            for j in range(len(PIinO[i])):
                count_cov[PIinO[i][j]] += lb_PI[s][i][j]
                #count_cov[PIinO[i][j]] += 1
                q[PIinO[i][j]] = max(q[PIinO[i][j]], cPIinO[s][i][j])

    #residuals = sum((q[p] - cPIAV[p] - count_cov[p]*lb_PI[s][p]) for p in lb_PI[s].keys())
    residuals = sum((q[p] - cPIAV[p] - count_cov[p]) for p in range(nPI))
    return residuals, q

def residuals_f_Js(selected, s, Js):
    # calcolo funzione obiettivo reale:
    q = np.array(cPIAV)
    count_cov = [0] * nPI
    for i in range(nO):
        if selected[i] == 1:
            for j in range(len(PIinO[i])):
                if Js[(PIinO[i][j], cPIinO[s][i][j])] > 1:
                    count_cov[PIinO[i][j]] += 1
                    q[PIinO[i][j]] = max(q[PIinO[i][j]], cPIinO[s][i][j])

    residuals = sum((q[j] - cPIAV[j] - count_cov[j]*lb_PI[s][j]) for j in lb_PI[s].keys())
    return residuals, q

def B0f(s, model, residuals, q):
    x = model.cbGetSolution(model._x)
    # calcolo il vantaggio che otterrei per ogni osservazione che potrei aggiungere (solo per quelle non selezionate)
    adv = [sum((cPIinO[s][i][j] - q[PIinO[i][j]] - lb_PI[s][i][j])
            for j in range(len(PIinO[i])) if cPIinO[s][i][j] > q[PIinO[i][j]]) if x[i] == 0 else 0 for i in range(nO) ]

    model.cbLazy(model._t[s] <= residuals + sum(adv[i] * model._x[i] for i in range(nO)))

def B1f(s, model, Js):

    x = model.cbGetSolution(model._x)
    #Js = compute_js(s)
    residuals_js, q_js = residuals_f_Js(x, s, Js)

    # calcolo il vantaggio che otterrei per ogni osservazione che potrei aggiungere (solo per quelle non selezionate)
    adv_a = [sum((cPIinO[s][i][j] - q_js[PIinO[i][j]] - lb_PI[s][PIinO[i][j]])
            for j in range(len(PIinO[i])) if cPIinO[s][i][j] > q_js[PIinO[i][j]]) if x[i] == 0 else 0 for i in range(nO)]

    # calcolo il vantaggio ottenuto per ogni osservazione o che che mi ha coperto i punti copribili con una certa qualità solo da o
    adv_b = [sum((cPIinO[s][i][j] - q_js[PIinO[i][j]] - lb_PI[s][PIinO[i][j]])
            for j in range(len(PIinO[i])) if Js[(PIinO[i][j], cPIinO[s][i][j])] == 1 and cPIinO[s][i][j] > q_js[PIinO[i][j]])
             if x[i] == 1 else 0 for i in range(nO)]

    model.cbLazy(model._t[s] <= residuals_js + sum((adv_a[i] + adv_b[i]) * model._x[i] for i in range(nO)))

def lazy(model, where):
    if where == GRB.Callback.MIPSOL:  # guardiamo se siamo in una sol intera del nostro problema
        # retrieves the solution
        x = model.cbGetSolution(model._x)
        ts = model.cbGetSolution(model._t)
        iter = model._iter
        t_finish = time.time()
        model._iter = iter + 1

        residuals = {}
        q = {}
        for s in S:
            # print(f'Model Obj in Scenario {s} = ', ts[s])
            residuals[s], q[s] = residuals_f(x, s)   # calcolo funzione obiettivo reale:
            # if ts == real_obj:
            # print(f"Soluzione Ottima Scenario {s} = {ts}")
            if ts[s] != residuals[s]:
            # print(f"Real Obj Scenario {s} = {real_obj}")

                # Cut B0f
                B0f(s, model, residuals[s], q[s])

                # Cut B1f
                #B1f(s, model, Js[s])

        h.write("\n" + str(iter + 1) + " " + str(t_finish - t1) + " " + str(sum(ts)) + " " + str(
            sum(residuals.values())))

SET_SIZE = 5  # numero set
UNIVERSE = list(range(1, 101))  # numeri da 1 a 50
random.seed(42)  # opzionale, per avere risultati riproducibili

# -----------------------------------------
for N_scenario in [1, 5, 10, 20, 50]:

    # genero i 5 gruppi di scenari
    sets = []
    seen = set()  # per evitare insiemi totalmente coincidenti
    while len(sets) < SET_SIZE:
        s = frozenset(random.sample(UNIVERSE, N_scenario))
        if s not in seen:
            seen.add(s)
            sets.append(list(s))

    if N_scenario in [10, 20, 50]:
        for ii in range(3, SET_SIZE):
            S = sets[ii]
            print(S)

            # Class of the quality of PIs in observations for each scenario s, weighted through set V
            cPIinO = {}
            for s in S:
                with open(f"{scenarios}/{name}/{name}(4)_{s}.txt", "r") as file:
                    cPIinO[s] = [[V[int(i)] for i in line.strip().split("\t")]
                                    if line != "" and line != "\n" else [] for line in file.readlines()]

            h = open(f"Soluzioni/Benders_residuals/Benders_residuals_evolution_{name}_{N_scenario}_{ii}_2.txt", "w+")
            h.write("Iteration " + "Time " + "Model_Solution " + "Real_Solution " + "Best_Solution")

            Js = {s:{} for s in S}
            for s in S:
                Js[s] = {(PIinO[i][j], cPIinO[s][i][j]): 0 for i in range(nO) for j in range(len(PIinO[i]))}
                for i in range(nO):
                    for j in range(len(PIinO[i])):
                        Js[s][(PIinO[i][j], cPIinO[s][i][j])] += 1

            # calcolo per ogni PI quante osservazioni lo coprono e la qualità minima di copertura in ogni scenario
            print('start')
            lens_PI = {PIinO[i][j]: 0 for i in range(nO) for j in range(len(PIinO[i]))}
            mins_PI = {s: {p: 0 for p in lens_PI.keys()} for s in S}

            for i in range(nO):
                for j in range(len(PIinO[i])):
                    lens_PI[PIinO[i][j]] += 1
                    #for s in S:
                     #   mins_PI[s][PIinO[i][j]] = min(cPIinO[s][i][j], mins_PI[s][PIinO[i][j]])

            lb_PI = {s: {o: [max(0, (cPIinO[s][o][p] - cPIAV[PIinO[o][p]]))/lens_PI[PIinO[o][p]] for p in range(len(PIinO[o]))] for o in range(nO)}  for s in S}
            print('done')

            # ---------------------------------- MASTER PROBLEM - MODEL --------------------------------------
            t1 = time.time()
            model = gp.Model()
            model.setParam("TimeLimit",3600)
            model.setParam(GRB.Param.Threads, 1)
            model.setParam(GRB.Param.Method, 2)#1
            model.Params.lazyConstraints = 1
            iter = 0

            # variables
            xo = model.addVars(range(nO), lb=0, ub=1, vtype=GRB.INTEGER, name='X')
            theta = model.addVars(S, lb=0, vtype=GRB.CONTINUOUS, name='T')
            model.update()

            # objective function
            z_tot = 0
            for s in S:
                for o in range(nO):
                    z_tot += xo[o] * sum(lb_PI[s][o][p] for p in range(len(PIinO[o])))

            theta_tot = 0
            for s in S: theta_tot += theta[s]
            model.setObjective(theta_tot+z_tot, sense=gp.GRB.MAXIMIZE)

            # constraints
            nbPicPerDay = {day[i]: 0 for i in range(nO)}
            for i in range(nO): nbPicPerDay[day[i]] += xo[i]
            model.addConstrs(nbPicPerDay[i] <= N for i in nbPicPerDay.keys())

            for s in S:
                ub = [sum((cPIinO[s][i][p] - cPIAV[PIinO[i][p]] - lb_PI[s][i][p])
                          for p in range(len(PIinO[i])) if cPIinO[s][i][p] > cPIAV[PIinO[i][p]]) for i in range(nO)]
                UB = sum(xo[i] * ub[i] for i in range(nO))
                model.addConstr(theta[s] <= UB)

            t2= time.time() #finish construction time
            model._iter = iter
            model._t = theta
            model._x = xo
            #model.write('Model.lp')
            print("go")
            model.optimize(lazy)
            t3 = time.time() #finish execution time

            visited = [0]*nPI
            selected = np.zeros(nO, dtype=int)

            for i in range(nO):
                selected[i] = xo[i].x
                if selected[i] == 1:
                    for j in PIinO[i]:
                        visited[j] = 1
            coverture = sum(visited)

            print(f'Is the solution optimal? {model.status == gp.GRB.OPTIMAL}\n')
            print('model objective function = ', theta_tot.getValue()+z_tot.getValue())
            obj = 0
            for s in S:
                real_obj, q = real_obj_f(selected, s)
                obj += real_obj
            print('real objective function = ', obj)
            print('number of PI visited = ', coverture)

            f = open(f"Soluzioni/Benders_residuals/Benders_residuals_results_{name}_{N_scenario}_{ii}_2.txt", "w")
            f.write('objective function = ' + str(obj)+'\n')
            f.write('number of PI visited = ' + str(coverture)+ '\n')
            f.write('total time = '+ str(t3-t1)+ '\n')
            f.write('construction time = '+ str(t2-t1)+ '\n')
            f.write('execution time = '+ str(t3-t2)+ '\n')
            f.write('UB = '+str(model.ObjBound)+ '\n')
            f.write('Gap = '+str(model.MIPGap)+ '\n')
            f.write('explored nodes= '+ str(model.NodeCount)+ '\n')
            for j in S:
                f.write(f"{j}\t")
            f.write('\n')
            for i in selected:
                f.write("%d\n" % i)
            f.close()

